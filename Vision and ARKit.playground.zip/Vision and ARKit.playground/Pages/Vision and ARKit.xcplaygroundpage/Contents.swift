/*:
 # Combining the powers of CoreML/Vision with the Powers of ARKit.
 In this page we will use ARKit in conjunction with CoreML and Vision to place the name of stuff on top of it 😃.
 # How to use it?
 It is very simple. Just move your iPad around a little bit and tap the screen. You will probably see a name tag on top of the object in the middle of the screen 🤓.
 
 
 But after all, you are (hopefully) wondering how is this possible? Actually it is very simple to implement 🤯. Let's go:
 */

import UIKit
import ARKit
import SceneKit
import Vision
import PlaygroundSupport


//: First we will create a class that inherits from UIViewController and implements ARSCNViewDelegate, now the latter one is the really important  because it will make sure that ARKit works well with SceneKit.
class ViewController: UIViewController, ARSCNViewDelegate {
    //now we will create a Augmented Reality SCenekit View or ARSCNView for short
    var sceneView = ARSCNView()
    /*:
     
     This constant defines the time it takes to turn a half turn.
     try changing it to see what happens 🤔
     */
    let rotationSpeed: Double = /*#-editable-code*/8/*#-end-editable-code*/
    let bubbleDepth: Float = 0.01
    var latestPrediciton: String = "..."
    
    var orientation: SCNVector3!
    //CoreML stuff
    var visionRequests = [VNRequest]()
    //here we will create a DispatchQueue for or Vision requests so that the "app" dosent come to a stop when we are classifying something
    let dispatchQueueML = DispatchQueue(label: "com.hw.dispatchqueueml")
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view = UIView()
        //view delegate
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        sceneView.session.run(configuration)
        //
        
        sceneView.delegate = self
        //if you want you can change this to true to see statistics of our scene (like FPS, NodeCount and PoligonCount
        sceneView.showsStatistics = /*#-editable-code*/false/*#-end-editable-code*/
        
        let scene = SCNScene()
        sceneView.scene = scene
        
        sceneView.autoenablesDefaultLighting = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(gestureRecognize:)))
        sceneView.addGestureRecognizer(tapGesture)
        
        //vision model
        guard let selectedModel = try? VNCoreMLModel(for: MobileNet().model) else {return}
        //configure vision-coreML
        let classificationRequest = VNCoreMLRequest(model: selectedModel, completionHandler: classificationCompleteHandler)
        classificationRequest.imageCropAndScaleOption = VNImageCropAndScaleOption.centerCrop
        visionRequests = [classificationRequest]
        
        
        
        
        
        //Start loop for coreml
        //loopCoreMLUpdate()
        self.view = sceneView
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        sceneView.session.run(configuration)
    }
    //completionHandler
    func classificationCompleteHandler(request: VNRequest, error: Error?) {
        //catch Errors
        if error != nil {
            print("error")
            return
        }
        guard let observations = request.results else {
            print("No results")
            return
        }
        
        // Get Classifications
        let classifications = observations[0...1] // top 2 results
            .compactMap({ $0 as? VNClassificationObservation })
            .map({ "\($0.identifier) \(String(format:"- %.2f", $0.confidence))" })
            .joined(separator: "\n")
        
        
        DispatchQueue.main.async { //Update the classifications on a async queue for no stuttering 😬

            // Store the latest prediction
            var objectName:String = "…"
            objectName = classifications.components(separatedBy: "-")[0]
            objectName = objectName.components(separatedBy: ",")[0]
            self.latestPrediciton = objectName
            
        }
        
    }
    //renderer
    
    //create text node
    func createNewBubbleParentNode(_ text: String) -> SCNNode {
        let billboardConstraint = SCNBillboardConstraint()
        billboardConstraint.freeAxes = SCNBillboardAxis.Y
        
        //text
        let bubble = SCNText(string: text, extrusionDepth: CGFloat(bubbleDepth))
        var font = UIFont(name: "Helvetica", size: 0.15)
        font = font?.withTraits(traits: .traitBold)
        bubble.font = font
        bubble.alignmentMode = CATextLayerAlignmentMode.center.rawValue
        bubble.firstMaterial?.diffuse.contents = UIColor.white
        bubble.firstMaterial?.specular.contents = UIColor.black
        bubble.firstMaterial?.isDoubleSided = true
        bubble.chamferRadius = CGFloat(bubbleDepth)
        //text node
        let (minBound, maxBound) = bubble.boundingBox
        let bubbleNode = SCNNode(geometry: bubble)
        bubbleNode.pivot = SCNMatrix4MakeTranslation((maxBound.x - minBound.x)/2, minBound.y, bubbleDepth/2)
        
        
        bubbleNode.scale = SCNVector3Make(0.3, 0.3, 0.3)
        //center node
        let sphere = SCNSphere(radius: 0.005)
        sphere.firstMaterial?.diffuse.contents = UIColor.blue
        let sphereNode = SCNNode(geometry: sphere)
        // bubble parent node
        let bubbleNodeParent = SCNNode()
        bubbleNodeParent.addChildNode(bubbleNode)
        bubbleNodeParent.addChildNode(sphereNode)
        //rotation
        let rotation = SCNAction.rotate(by: .pi, around: SCNVector3(0,1,0), duration: rotationSpeed)
        let infine = SCNAction.repeatForever(rotation)
        bubbleNodeParent.runAction(infine)
        // bubbleNodeParent.constraints = [billboardConstraint]
        return bubbleNodeParent
    }
    
    //tap Funcion
    @objc func handleTap(gestureRecognize: UITapGestureRecognizer) {
        //Hit test real world
        //: finds the middle point of the screen
        let screenCentre : CGPoint = CGPoint(x: self.sceneView.bounds.midX, y: self.sceneView.bounds.midY)
        //: casts a "laser" on the center of the screen
        let arHitTestResults: [ARHitTestResult] = sceneView.hitTest(screenCentre, types: [.featurePoint])
        //: if the hit is susscesful create a closest result
        if let closestResult = arHitTestResults.first {
            //get coordinates
            let transform: matrix_float4x4 = closestResult.worldTransform
            let worldCoord: SCNVector3 = SCNVector3Make(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
            //create text
            let node: SCNNode = createNewBubbleParentNode(latestPrediciton)
            sceneView.scene.rootNode.addChildNode(node)
            node.position = worldCoord
            
        }
    }
    
    
    //functions to update CoreML
    func updateCoreML() {
        //create a pixelBuffer of our current frame
        let pixbuff: CVPixelBuffer? = (sceneView.session.currentFrame?.capturedImage)
        if pixbuff == nil {
            return
        }
        //create a ciImage of our pixelBuffer
        let ciImage = CIImage(cvPixelBuffer: pixbuff!)
        //create a Vision classification request based on current frame
        let imageRequestHandler = VNImageRequestHandler(ciImage: ciImage, options: [:])
        
        do {
            //try to execute the request
            try imageRequestHandler.perform(self.visionRequests)
        } catch {
            print(error)
        }
        
    }
    func loopCoreMLUpdate(){
        DispatchQueue.global().async {
            self.updateCoreML()
            self.loopCoreMLUpdate()
        }
    }
    
    
}


extension UIFont {
    // Based on: https://stackoverflow.com/questions/4713236/how-do-i-set-bold-and-italic-on-uilabel-of-iphone-ipad
    func withTraits(traits:UIFontDescriptor.SymbolicTraits...) -> UIFont {
        let descriptor = self.fontDescriptor.withSymbolicTraits(UIFontDescriptor.SymbolicTraits(traits))
        return UIFont(descriptor: descriptor!, size: 0)
    }
}
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
PlaygroundPage.current.needsIndefiniteExecution = true

