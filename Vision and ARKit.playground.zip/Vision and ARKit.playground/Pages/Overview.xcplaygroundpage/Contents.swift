/*:
 # Table of Contents:

* [Getting started with Vision](Getting%20Started%20With%20Vision)
* [Vision and ARKit](Vision%20and%20ARKit)
 
# Overview.
In this Playground you will learn the basics of CoreML, primarily for image recognition using Vision framework and a MobileNet model. Hope you like it 😃

# Introduction to machine learning.
 
 In it's purest form machine learning is just a lot, and I do really mean a **LOT**, of linear algebra and it's very complicated to explain in this simple Playground. I mean it's literally a full 4 year collage course. For a fun visualization we have a little comic from our friends at xkcd:
 
 ![xkcd reference](machine_learning.png)
 
 # Workflow of Vision and CoreML.
 It goes as follows:
 
 * Instantiate our model class;
 * Modify our image into a CIImage
 * Create a request
 * Create a request handler
 * Execute the request
 * Treat results.
 
 See it isn't so hard. But don't worry if you are still confused. The next page will, hopefully, make it very clear.

 (Also there is a little surprise if you run the code in this page and tilt your iPad 😲.)
*/

//#-hidden-code
import PlaygroundSupport
import UIKit
import CoreMotion
import simd
class EasterEgg: UIViewController {
    var motionManager: CMMotionManager!
    /*#-editable-code*//*#-end-editable-code*/

    
    var acceleration: double3!
    var labelView: UIView!
    var animator: UIDynamicAnimator!
    var gravity: UIGravityBehavior!
    var collision: UICollisionBehavior!
    override func loadView() {
        super.loadView()
        view.backgroundColor = UIColor.white
        //labelViewConfig
        labelView = UIView(frame: CGRect(x: 100, y: 100, width: 200, height: 40))
        labelView.backgroundColor = UIColor.white
        let label = UILabel(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: labelView.frame.size))
        label.text = "I \u{2764} CoreML"
        
        
        label.font = UIFont.systemFont(ofSize: 30)
        label.textAlignment = .center
        labelView.addSubview(label)
        view.addSubview(labelView)
        //force
        gravity = UIGravityBehavior(items: [labelView])
        //collision
        collision = UICollisionBehavior(items: [labelView])
        collision.translatesReferenceBoundsIntoBoundary = true
        collision.addBoundary(withIdentifier: "botton" as NSCopying, from: CGPoint(x: 0 as CGFloat, y: self.view.frame.height), to: CGPoint(x: self.view.frame.width, y: self.view.frame.height))
        
        //animator
        animator = UIDynamicAnimator(referenceView: view)
        animator.addBehavior(collision)
        animator.addBehavior(gravity)
        //start updates
        startUpdates()
    }
    func startUpdates() {
        motionManager = CMMotionManager()
        if motionManager.isDeviceMotionAvailable {print("motion avalible")} else {
            print("oh no")
            return}
        motionManager.accelerometerUpdateInterval = TimeInterval(0.001)
        motionManager.showsDeviceMovementDisplay
        motionManager.startAccelerometerUpdates(to: .main) { accelerometerData, error in
            guard let accelerometerData = accelerometerData else { return }
            
            self.acceleration = [accelerometerData.acceleration.x, accelerometerData.acceleration.y, accelerometerData.acceleration.z]
            print(self.acceleration!.x)
            self.gravity.gravityDirection = CGVector(dx: self.acceleration.y * -10, dy: self.acceleration.x * -10)
            
        }
    }
}
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = EasterEgg()
//#-end-hidden-code
//: [Let's get started](@next)
