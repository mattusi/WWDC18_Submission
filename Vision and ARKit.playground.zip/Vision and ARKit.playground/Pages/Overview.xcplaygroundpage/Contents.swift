
import PlaygroundSupport
import UIKit
import CoreMotion
import simd
class EasterEgg: UIViewController {
    var motionManager: CMMotionManager!
    var acceleration: double3!
    var labelView: UIView!
    var animator: UIDynamicAnimator!
    var gravity: UIGravityBehavior!
    var collision: UICollisionBehavior!
    override func loadView() {
        
        super.loadView()
        self.view = UIView()
        view.backgroundColor = UIColor.white
        //labelViewConfig
        labelView = UIView(frame: CGRect(x: 100, y: 100, width: 200, height: 40))
        labelView.backgroundColor = UIColor.white
        let label = UILabel(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: labelView.frame.size))
        label.text = "I ❤️ CoreML"
        
        
        label.font = UIFont.systemFont(ofSize: 30)
        label.textAlignment = .center
        labelView.addSubview(label)
        view.addSubview(labelView)
        //force
        gravity = UIGravityBehavior(items: [labelView])
        //collision
        collision = UICollisionBehavior(items: [labelView])
        collision.translatesReferenceBoundsIntoBoundary = true
        collision.addBoundary(withIdentifier: "botton" as NSCopying, from: CGPoint(x: 0 as CGFloat, y: self.view.frame.height), to: CGPoint(x: self.view.frame.width, y: self.view.frame.height))
        
        //animator
        animator = UIDynamicAnimator(referenceView: view)
        animator.addBehavior(collision)
        animator.addBehavior(gravity)
        //start updates
        //startUpdates()
    }
    func startUpdates() {
        motionManager = CMMotionManager()
        if motionManager.isDeviceMotionAvailable {print("motion avalible")} else {
            print("oh no")
            return}
        motionManager.accelerometerUpdateInterval = TimeInterval(0.001)
        motionManager.showsDeviceMovementDisplay
        motionManager.startAccelerometerUpdates(to: .main) { accelerometerData, error in
            guard let accelerometerData = accelerometerData else { return }
            
            self.acceleration = [accelerometerData.acceleration.x, accelerometerData.acceleration.y, accelerometerData.acceleration.z]
            print(self.acceleration!.x)
            self.gravity.gravityDirection = CGVector(dx: self.acceleration.y * -10, dy: self.acceleration.x * -10)
            
        }
    }
}
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = EasterEgg()

