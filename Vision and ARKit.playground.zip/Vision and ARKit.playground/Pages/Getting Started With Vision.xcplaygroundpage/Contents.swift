/*:
 # Using Machine Learning to classify images.
 In this page you will learn how to feed a static picture to a CoreML model throught Vision and get a result.
 # Objectives:
 * Get to know how a request works;
 * See limitations and capabilities of our model;
 * Have fun with Machine Learning.
 
 # Let's go 
 Alright so first things first, import the necessery modules:
 */
//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
import Vision
import CoreML
import ImageIO
//#-hidden-code

public class ImageClassificationViewController: UIViewController {
    
    var overlayView: UIView!
    var alertView: UIView!
    var imageView: UIImageView!
    var attachmentBehavior: UIAttachmentBehavior!
    var snapBehavior: UISnapBehavior!
    var classificationLabel = UILabel()
    var timer: Timer!
    var imageArrayIndex = 0
    var littleView: UIView!
    
//#-end-hidden-code
//: This is our array of images, try changing the images in it, and see if our model can discover what it is 😄
    var imageArray = [/*#-editable-code*/#imageLiteral(resourceName: "honda.jpg"),#imageLiteral(resourceName: "pug.jpg"),#imageLiteral(resourceName: "snow-leopard-640x400.jpg"),#imageLiteral(resourceName: "salmon.jpg"),#imageLiteral(resourceName: "coffee.JPG"),#imageLiteral(resourceName: "backpack.jpg"),#imageLiteral(resourceName: "hamburger.jpg")/*#-end-editable-code*/]
//#-hidden-code
    var animator: UIDynamicAnimator!
    
    public override func loadView() {
        super.loadView()
        //view creation
        self.view = UIView()
       littleView = UIView(frame: CGRect(x: 0, y: 0, width: 432, height: 630))
        
        littleView.backgroundColor = UIColor.white
        view.backgroundColor = UIColor.white
        //classifiling label
        let classifingLabel = UILabel(frame: CGRect(x: 0, y: littleView.center.y, width: littleView.bounds.width, height: 50))
        classifingLabel.text = "Classifying image..."
        classifingLabel.textColor = UIColor.red
        classifingLabel.font = UIFont(name: "Helvetica", size: 40)
        classifingLabel.textAlignment = .center
        littleView.addSubview(classifingLabel)
        //animator
        animator = UIDynamicAnimator(referenceView: littleView)
        //alert
        createOverlay()
        createAlert()
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(showAlert), userInfo: nil, repeats: false)
        view.addSubview(littleView)
        //first classification
//#-end-hidden-code
//: Now we call our function that receives an UIImage and updates our label 🤔
    updateClassifications(for: imageArray[imageArrayIndex])
//#-hidden-code
    }
    
//#-end-hidden-code
//:Now for the real deal. We need to create a VNCoreMLRequest
    lazy var classificationRequest: VNCoreMLRequest = {
        do {
            //We will try instanced the model
            let model = try VNCoreMLModel(for: MobileNet().model)
            //Then we will prepare the request
            let request = VNCoreMLRequest(model: model, completionHandler: { [weak self] request, error in
                self?.processClassifications(for: request, error: error)
            })
            
            request.imageCropAndScaleOption = .centerCrop
            return request
        } catch {
            fatalError("failed to load ML model")
        }
    }()
    
//:This function receives the image for the classification and performs it 😱
    func updateClassifications(for image: UIImage) {
        classificationLabel.text = "Classifying..."
        
        let orientation = CGImagePropertyOrientation(rawValue: UInt32(image.imageOrientation.rawValue))
        guard let ciImage = CIImage(image: image) else { fatalError("Unable to create image")}
        
        DispatchQueue.global(qos: .userInitiated).async {
            let handler = VNImageRequestHandler(ciImage: ciImage, orientation: orientation ?? CGImagePropertyOrientation(.down))
            do {
                try handler.perform([self.classificationRequest])
                
            } catch {
                print()
            }
        }
    }
//:And this function checks the results of the classification and updates the label accordingly 😁
    func processClassifications(for request: VNRequest, error: Error?) {
        if let theError = error {
            print("Error: \(theError.localizedDescription)")
            return
        }
        guard let observations = request.results else {
            print("No results")
            return
        }
        //For a fun little thing try changing the number of results that appear on screen.
        let classifications = observations[0 ... /*#-editable-code*/2/*#-end-editable-code*/] // top 2 results
            .compactMap({ $0 as? VNClassificationObservation })
            //Or change the confidence of the results:
            .compactMap({$0.confidence >  /*#-editable-code*/0.01/*#-end-editable-code*/ ? $0 : nil})
            .map({ "\($0.identifier) \(String(format:"%.2f", $0.confidence))" })
            .joined(separator: "\n")
        
        DispatchQueue.main.async {
            self.classificationLabel.text = classifications
            
        }
        
    }
    
 
//#-hidden-code
    func createOverlay() {
        // Create a gray view and set its alpha to 0 so it isn't visible
        overlayView = UIView(frame: littleView.frame)
        overlayView.backgroundColor = UIColor.gray
        overlayView.alpha = 0.0
        littleView.addSubview(overlayView)
    }
    
    @objc func createAlert() {
        // Here the red alert view is created. It is created with rounded corners and given a shadow around it
        let alertWidth: CGFloat = 250
        let alertHeight: CGFloat = 350
        let alertViewFrame: CGRect = CGRect(x: -250, y: -350, width: alertWidth, height: alertHeight)
       
        alertView = UIView(frame: alertViewFrame)
        alertView.backgroundColor = UIColor.white
        alertView.alpha = 0.0
        alertView.layer.cornerRadius = 10;
        alertView.layer.shadowColor = UIColor.black.cgColor;
        alertView.layer.shadowOffset = CGSize(width: 0, height: 5)
        alertView.layer.shadowOpacity = 0.3;
        alertView.layer.shadowRadius = 10.0;
        //create image
        let imageViewFrame = CGRect(x: 0, y: 5, width: alertWidth, height: alertHeight - 170)
        imageView = UIImageView(frame: imageViewFrame)
        //run thru the image array
        if imageArrayIndex > imageArray.count - 2 {
            imageArrayIndex = 0
        } else {
            imageArrayIndex += 1
        }
        
        
        
        imageView.image = imageArray[imageArrayIndex]
        imageView.contentMode = .scaleAspectFit
        alertView.addSubview(imageView)
        //Machine Learing
       let classificationLabelFrame = CGRect(x: 0, y: imageView.frame.height + 10, width: alertWidth, height: 100)
        classificationLabel = UILabel(frame: classificationLabelFrame)
        classificationLabel.numberOfLines = 6
        alertView.addSubview(classificationLabel)
        // Create a button and set a listener on it for when it is tapped. Then the button is added to the alert view
        let button = UIButton(type: UIButton.ButtonType.system) as UIButton
        button.setTitle("Next Image", for: UIControl.State.normal)
        button.backgroundColor = UIColor.lightGray
        button.frame = CGRect(x: 0, y: alertViewFrame.height - 40, width: alertWidth, height: 40.0)
        
        button.addTarget(self, action: #selector(dismissAlert), for: UIControl.Event.touchUpInside)
        
        alertView.addSubview(button)
        littleView.addSubview(alertView)
    }
    
    @objc func showAlert() {
        // When the alert view is dismissed, I destroy it, so I check for this condition here
        // since if the Show Alert button is tapped again after dismissing, alertView will be nil
        // and so should be created again
        if (alertView == nil) {
            createAlert()
        }
        

        
        animator.removeAllBehaviors()
        
        // Animate in the overlay
        UIView.animate(withDuration: 0.4) {
            self.overlayView.alpha = 1.0
        }
        
        // Animate the alert view using UIKit Dynamics.
        alertView.alpha = 1.0
        
        let snapBehaviour: UISnapBehavior = UISnapBehavior(item: alertView, snapTo: littleView.center)
        animator.addBehavior(snapBehaviour)
    }
    
    @objc func dismissAlert() {
        
        animator.removeAllBehaviors()
        
        let gravityBehaviour: UIGravityBehavior = UIGravityBehavior(items: [alertView])
        gravityBehaviour.gravityDirection = CGVector(dx: 0, dy: 10)
        animator.addBehavior(gravityBehaviour)
        
        // This behaviour is included so that the alert view tilts when it falls, otherwise it will go straight down
        let itemBehaviour: UIDynamicItemBehavior = UIDynamicItemBehavior(items: [alertView])
        itemBehaviour.addAngularVelocity(CGFloat(-Double.pi / 2), for: alertView)
        animator.addBehavior(itemBehaviour)
        
        // Animate out the overlay, remove the alert view from its superview and set it to nil
        // If you don't set it to nil, it keeps falling off the screen and when Show Alert button is
        // tapped again, it will snap into view from below. It won't have the location settings we defined in createAlert()
        // And the more it 'falls' off the screen, the longer it takes to come back into view, so when the Show Alert button
        // is tapped again after a considerable time passes, the app seems unresponsive for a bit of time as the alert view
        // comes back up to the screen
        UIView.animate(withDuration: 0.4, animations: {
            self.overlayView.alpha = 0.0
        }, completion: {
            (value: Bool) in
            self.alertView.removeFromSuperview()
            self.alertView = nil
            self.showAlert()
            self.updateClassifications(for: self.imageArray[self.imageArrayIndex])
            
            
        })
        
    }
    
    @IBAction func showAlertView(sender: UIButton) {
        showAlert()
    }
    
   
    
}
    
    
    
    

//#-hidden-code
extension CGImagePropertyOrientation {
    /**
     Converts a `UIImageOrientation` to a corresponding
     `CGImagePropertyOrientation`. The cases for each
     orientation are represented by different raw values.
     
     - Tag: ConvertOrientation
     */
    init(_ orientation: UIImage.Orientation) {
        switch orientation {
        case .up: self = .up
        case .upMirrored: self = .upMirrored
        case .down: self = .down
        case .downMirrored: self = .downMirrored
        case .left: self = .left
        case .leftMirrored: self = .leftMirrored
        case .right: self = .right
        case .rightMirrored: self = .rightMirrored
        }
    }
}
PlaygroundPage.current.liveView = ImageClassificationViewController()
//#-end-hidden-code
//: And run the code to see the results. Don't forget to click on "Next image" button.
//: [Vision and ARKit combined](@next)
